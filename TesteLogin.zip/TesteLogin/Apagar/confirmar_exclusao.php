<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmação de Exclusão de Perfil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        input[type="submit"] {
            width: 100px;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #dc3545;
            color: #fff;
            cursor: pointer;
            font-weight: bold;
            outline: none;
            margin-right: 10px;
        }
        a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Deseja realmente excluir este perfil?</h2>
        <form method="post" action="excluir_perfil.php">
            <input type="hidden" name="email" value="<?php echo $_GET['email']; ?>">
            <input type="submit" name="confirmar_exclusao" value="Sim">
            <a href="../Index.php">Não</a>
        </form>
    </div>
</body>
</html>
