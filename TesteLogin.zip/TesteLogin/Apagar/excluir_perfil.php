<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "teste");

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Inicializar a variável de erro
$error_message = "";

// Verificar se o formulário foi submetido para exclusão de perfil
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmar_exclusao"])) {
    // Recuperar o email do perfil a ser excluído
    $email = $_POST["email"];

    // Preparar a consulta SQL para excluir o perfil da base de dados
    $sql_excluir_perfil = "DELETE FROM usuarios WHERE email=?";
    $stmt_excluir_perfil = $conn->prepare($sql_excluir_perfil);
    $stmt_excluir_perfil->bind_param("s", $email);

    // Executar a consulta para excluir o perfil
    if ($stmt_excluir_perfil->execute()) {
        // Redirecionar para a página de sucesso de exclusão de perfil
        header("Location: sucesso_exclusao.html");
        exit();
    } else {
        // Se houver um erro ao excluir o perfil, definir uma mensagem de erro
        $error_message = "Erro ao excluir o perfil: " . $conn->error;
    }

    // Fechar a declaração
    $stmt_excluir_perfil->close();
} else {
    // Se o formulário não foi submetido corretamente, redirecionar para a página inicial
    header("Location: ../Index.php");
    exit();
}
?>
