<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "teste");

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Inicializar a variável de erro
$error_message = "";

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["verificar_perfil"])) {
    // Recuperar os dados do formulário
    $email = $_POST["email"];
    $nif = $_POST["nif"];

    // Preparar a consulta SQL para verificar se o perfil existe
    $sql_verificar_perfil = "SELECT * FROM usuarios WHERE email=? AND nif=?";
    $stmt_verificar_perfil = $conn->prepare($sql_verificar_perfil);
    $stmt_verificar_perfil->bind_param("ss", $email, $nif);
    $stmt_verificar_perfil->execute();
    $result_verificar_perfil = $stmt_verificar_perfil->get_result();

    // Verificar se o perfil foi encontrado
    if ($result_verificar_perfil->num_rows > 0) {
        // Redirecionar para a página de confirmação de exclusão
        header("Location: confirmar_exclusao.php?email=$email");
        exit();
    } else {
        // Se o perfil não for encontrado, exibir mensagem de erro
        $error_message = "Perfil não encontrado. Verifique o e-mail e o NIF inseridos.";
    }

    // Fechar a declaração
    $stmt_verificar_perfil->close();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="apagarstyle.css">
    <title>Verificar Perfil para Exclusão</title>
</head>
<body>
<div>
    <h2>Verificar Perfil para Excluir</h2>

    <!-- Exibir mensagem de erro -->
    <?php if (!empty($error_message)): ?>
        <div style="color: red; margin-bottom: 10px;"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" placeholder="Email" required>
        </div>
        <div>
            <h2></h2>
            <label for="nif">NIF</label>
            <input type="text" name="nif" id="nif" placeholder="NIF" required>
        </div>
        <input type="submit" name="verificar_perfil" value="Verificar Perfil">
    </form>
</div>
</body>
</html>
