<?php
// Conexão com o banco de dados (substitua pelas suas credenciais)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teste";
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Definir a timezone
date_default_timezone_set('Europe/Lisbon');
echo "Script em execução...<br>";

// Consulta para selecionar as linhas da tabela
$sql = "SELECT id, data_expiracao FROM verificacoes";
$result = $conn->query($sql);

// Verificar se há resultados e processá-los
if ($result) {
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data_expiracao = strtotime($row["data_expiracao"]);
            $agora = strtotime("now");
            echo "Data de expiração: " . date('Y-m-d H:i:s', $data_expiracao) . "<br>";
            echo "Data atual: " . date('Y-m-d H:i:s', $agora) . "<br>";

            // Comparar a data de expiração com a data atual
            if ($agora > $data_expiracao) {
                // Se a data atual for maior que a data de expiração, apagar a linha
                $id = $row["id"];
                $sql_delete = "DELETE FROM verificacoes WHERE id = $id";
                if ($conn->query($sql_delete) === TRUE) {
                    echo "Registro com ID " . $id . " apagado com sucesso.<br>";
                } else {
                    echo "Erro ao apagar registro: " . $conn->error;
                }
            }
        }
    } else {
        echo "0 resultados";
    }
} else {
    echo "Erro na consulta: " . $conn->error;
}

// Fechar a conexão com o banco de dados
$conn->close();
?>
 