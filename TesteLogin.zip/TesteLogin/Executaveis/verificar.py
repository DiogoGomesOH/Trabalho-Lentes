import mysql.connector
import smtplib
from email.mime.text import MIMEText
from datetime import datetime

# Função para enviar e-mail
def enviar_email(destinatario, assunto, mensagem):
    remetente = 'diogogomes8076@gmail.com'
    senha = 'frjg otxd muzb vhvu'  # Substitua pela senha de aplicativo que você gerou

    # Configurar conexão com o servidor SMTP do Gmail
    servidor_smtp = 'smtp.gmail.com'
    porta_smtp = 587
    server = smtplib.SMTP(servidor_smtp, porta_smtp)
    server.starttls()
    server.login(remetente, senha)

    # Criar mensagem MIME
    msg = MIMEText(mensagem)
    msg['From'] = remetente
    msg['To'] = destinatario
    msg['Subject'] = assunto

    # Enviar e-mail
    server.sendmail(remetente, destinatario, msg.as_string())
    # Fechar conexão
    server.quit()

# Conectar à base de dados MySQL
conexao = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="teste"
)
cursor = conexao.cursor()

# Consulta para recuperar os registros com a data atual
data_atual = datetime.now().date()
consulta_sql = "SELECT email, nome, nif FROM usuarios WHERE data_notificacao = %s"
cursor.execute(consulta_sql, (data_atual,))

# Enviar e-mails para os usuários encontrados
for row in cursor.fetchall():
    email = row[0]
    nome = row[1]
    nif = row[2]
    assunto = 'Lembrete lentes'
    mensagem = f'Olá {nome}!\n\nAs suas lentes estão a acabar.\nDeseja encomandar novas lentes?\n\nSeu NIF: {nif}'
    enviar_email(email, assunto, mensagem)

# Fechar conexão com a base de dados
conexao.close()
