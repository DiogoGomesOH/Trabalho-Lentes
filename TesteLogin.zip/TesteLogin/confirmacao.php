<?php
// CONFIRMAR EMAIL PARA AVANCAR
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
$mensagem_erro = ""; // Variável para armazenar a mensagem de erro

if (isset($_POST['confirmar'])) {
    $codigo_confirmacao_usuario = $_POST['codigo_confirmacao'];

    if (isset($_SESSION['codigo_verificacao']) && $_SESSION['codigo_verificacao'] == $codigo_confirmacao_usuario) {
        // Código de confirmação correto, realizar a inserção na tabela principal

        // Recuperar os dados do registro da sessão
        $nome = $_SESSION['nome'];
        $email = $_SESSION['email'];
        $nif = $_SESSION['nif'];
        $data_inicio = $_SESSION['data_inicio'];
        $lente = $_SESSION['lente'];
        $embalagem = $_SESSION['embalagem'];

        // Conectar à base de dados MySQL e inserir os dados na tabela principal
        $conexao = new mysqli("localhost", "root", "", "teste");
        if ($conexao->connect_error) {
            die("Erro de conexão: " . $conexao->connect_error);
        }

        $stmt = $conexao->prepare("INSERT INTO usuarios (nome, email, nif, data_inicio, lente, embalagem) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisss", $nome, $email, $nif, $data_inicio, $lente, $embalagem);
        $stmt->execute(); // Executa a inserção na tabela principal
        $stmt->close();
        $conexao->close();

        // Redirecionar o usuário para a página de sucesso
        header("Location: sucedido.html");
        exit();
    } else {
        // Código de confirmação incorreto, definir mensagem de erro
        $mensagem_erro = "Código de confirmação incorreto. Por favor, tente novamente.";
    }
}

// Adiciona a funcionalidade de reenviar o código de confirmação
if (isset($_POST['reenviar'])) {
    // Gerar novo código de verificação
    $codigo_verificacao = mt_rand(100000, 999999);
    $_SESSION['codigo_verificacao'] = $codigo_verificacao;

    // Atualiza o código de verificação na base de dados
    $conexao = new mysqli("localhost", "root", "", "teste");
    if ($conexao->connect_error) {
        die("Erro de conexão: " . $conexao->connect_error);
    }

    $stmt_update = $conexao->prepare("UPDATE verificacoes SET codigo_verificacao = ? WHERE email = ?");
    $stmt_update->bind_param("is", $codigo_verificacao, $_SESSION['email']);
    $stmt_update->execute();
    $stmt_update->close();
    $conexao->close();

    // Envio de e-mail com o novo código de confirmação
    require_once 'vendor/autoload.php'; // Carrega o PHPMailer

    $mail = new PHPMailer(true); // Ativa exceções

    try {
        $mail->isSMTP(); // Define o uso do SMTP
        $mail->Host = 'smtp.gmail.com'; // Endereço do servidor SMTP
        $mail->SMTPAuth = true; // Ativar autenticação SMTP
        $mail->Username = 'Diogogomes8076@gmail.com'; // Endereço de e-mail
        $mail->Password = 'frjg otxd muzb vhvu'; // Senha de e-mail
        $mail->SMTPSecure = 'tls'; // Tipo de criptografia
        $mail->Port = 587; // Porta SMTP
        
        $mail->setFrom('Diogogomes8076@gmail.com', 'Diogo');
        $mail->addAddress($_SESSION['email']);
        $mail->Subject = 'Confirmação de E-mail';
        $mail->Body = "Olá {$_SESSION['nome']},\n\nSeu novo código de confirmação é: $codigo_verificacao";
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->send();
        
        // Redireciona de volta para a página de confirmação
        header("Location: confirmacao.php");
        exit();
    } catch (Exception $e) {
        echo "Erro ao enviar o e-mail de confirmação: {$mail->ErrorInfo}";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="confirmacaostyle.css">
    <title>Confirmação</title>
</head>
<body>
    <h2>Confirmação de E-mail</h2>
    <form method="post">
        <label for="codigo_confirmacao">Insira o código de confirmação enviado para o seu email:</label><br>
        <input type="text" id="codigo_confirmacao" name="codigo_confirmacao"><br><br>
        <span class="mensagem-erro"><?php echo $mensagem_erro; ?></span>
        <input type="submit" name="confirmar" value="Confirmar">
    </form>
    <!-- Formulário para reenviar o código de confirmação -->
    <form method="post">
        <input type="submit" name="reenviar" value="Não recebeu o código? Clique aqui para reenviar">
    </form>
</body>
</html>
