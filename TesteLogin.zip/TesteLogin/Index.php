<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'vendor/autoload.php'; // Carrega o PHPMailer
session_start();

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register"])) {
    // Recuperar os dados do formulário
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $nif = $_POST["nif"];
    $data_inicio = $_POST["data_inicio"];
    $tipo_lentes = $_POST["tipo_lentes"];
    $tipo_embalagem = $_POST["tipo_embalagem"];

    // Conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "teste");

    // Verificar conexão
    if ($conn->connect_error) {
        die("Falha na conexão: " . $conn->connect_error);
    }

    // Verificar se o email já está em uso
    $sql_verificar_email = "SELECT * FROM usuarios WHERE email=?";
    $stmt_verificar_email = $conn->prepare($sql_verificar_email);
    $stmt_verificar_email->bind_param("s", $email);
    $stmt_verificar_email->execute();
    $result_verificar_email = $stmt_verificar_email->get_result();

    // Verificar se o NIF já está em uso
    $sql_verificar_nif = "SELECT * FROM usuarios WHERE nif=?";
    $stmt_verificar_nif = $conn->prepare($sql_verificar_nif);
    $stmt_verificar_nif->bind_param("s", $nif);
    $stmt_verificar_nif->execute();
    $result_verificar_nif = $stmt_verificar_nif->get_result();

    // Se o email e NIF estiverem disponíveis e o NIF for válido, prosseguir com o envio do email de confirmação
    if ($result_verificar_email->num_rows == 0 && $result_verificar_nif->num_rows == 0) {
        // Gerar e armazenar o código de verificação na sessão
        $codigo_verificacao = mt_rand(100000, 999999);
        $_SESSION['codigo_verificacao'] = $codigo_verificacao;
        $_SESSION['nome'] = $nome;
        $_SESSION['email'] = $email;
        $_SESSION['nif'] = $nif;
        $_SESSION['data_inicio'] = $data_inicio;
        $_SESSION['lente'] = $tipo_lentes;
        $_SESSION['embalagem'] = $tipo_embalagem;

        // Inserir os dados na tabela 'verificacoes'
        $stmt_verificacao = $conn->prepare("INSERT INTO verificacoes (email, codigo_verificacao) VALUES (?, ?)");
        $stmt_verificacao->bind_param("si", $email, $codigo_verificacao);
        $stmt_verificacao->execute();
        $stmt_verificacao->close();

        // Enviar e-mail de confirmação usando o PHPMailer
        $mail = new PHPMailer(true); // Ativa exceções

        try {
            $mail->isSMTP(); // Define o uso do SMTP
            $mail->Host = 'smtp.gmail.com'; // Endereço do servidor SMTP
            $mail->SMTPAuth = true; // Ativar autenticação SMTP
            $mail->Username = 'Diogogomes8076@gmail.com'; // Endereço de e-mail
            $mail->Password = 'frjg otxd muzb vhvu'; // Senha de e-mail
            $mail->SMTPSecure = 'tls'; // Tipo de criptografia
            $mail->Port = 587; // Porta SMTP
            
            $mail->setFrom('Diogogomes8076@gmail.com', 'Diogo');
            $mail->addAddress($email);
            $mail->Subject = 'Confirmação de E-mail';
            $mail->Body = "Olá $nome,\n\nSeu código de confirmação é: $codigo_verificacao";
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            $mail->send();

            // Redirecionar para a página de confirmação
            header("Location: confirmacao.php");
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar o e-mail de confirmação: {$mail->ErrorInfo}";
        }
    } else {
        $error_message = "O email ou NIF já estão em uso por outro usuário. Por favor, escolha outros.";
    }

    // Fechar as declarações e a conexão com o banco de dados
    $stmt_verificar_email->close();
    $stmt_verificar_nif->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Login</title>
</head>
<body>
    <div class="main-login">
        <div class="left-login">
            <img src="imagens/logo.svg" class="left-login-image" alt="Logo">
        </div>
        <div class="right-login">
            <div class="card-login">
                <h1>REGISTE-SE</h1>
                <form id="register-form" action="" method="post">
                    <div class="textfield">
                        <label for="nome">Nome</label>
                        <input type="text" name="nome" id="nome" placeholder="Nome" required>
                    </div>
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Email" required>
                    </div>
                    <div class="textfield">
                        <label for="nif">NIF</label>
                        <input type="text" name="nif" id="nif" placeholder="NIF" required>
                    </div>
                    <div class="textfield">
                        <label for="data_inicio">Início de Uso</label>
                        <input type="date" id="data_inicio" name="data_inicio" required>
                    </div>
                    <div class="textfield">
                        <label for="tipo_lentes">Tipo de lente</label>
                        <div class="select-container">
                            <select id="tipo_lentes" name="tipo_lentes" onchange="mostrarUnidades()" required>
                                <option value="Diária">Diária</option>
                                <option value="Quinzenal">Quinzenal</option>
                                <option value="Mensal">Mensal</option>
                                <option value="Trimestral">Trimestral</option>
                                <option value="Anua">Anual</option>
                            </select>
                            <span class="select-arrow"></span>
                        </div>
                    </div>
                    <div class="textfield">
                        <label for="tipo_embalagem">Quantidade da Embalagem</label>
                        <div class="select-container">
                            <select id="tipo_embalagem" name="tipo_embalagem" required>
                                <option value="1">1 unidade</option>
                                <option value="3">3 unidades</option>
                                <option value="6">6 unidades</option>
                                <option value="30">30 unidades</option>
                                <option value="90">90 unidades</option>
                            </select>
                            <span class="select-arrow"></span>
                        </div>
                    </div>
                    <!-- Botão de registro -->
                    <button type="submit" class="btn-login">Registar</button>
                    <!-- Campo oculto para indicar o envio do formulário -->
                    <input type="hidden" name="register" value="1">
                    <!-- Exibir mensagem de erro -->
                    <?php if (!empty($error_message)): ?>
                        <div style="color: red;"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <p>Já possui um registo?</p>
                    <a href="../TesteLogin/Alterar/alterar.php" class="btn-login-action">Alterar</a>
                    <span class="btn-separator">|</span> <!-- Aqui está o separador -->
                    <a href="../TesteLogin/Apagar/apagar.php" class="btn-login-action">Apagar</a>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('register-form').addEventListener('submit', function(event) {
            var form = event.target;
            if (!form.checkValidity()) {
                event.preventDefault();
                alert('Por favor, preencha todos os campos.');
            }
        });
    </script>
</body>
</html>
