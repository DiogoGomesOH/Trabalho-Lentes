<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "teste");

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Inicializar a variável de erro
$error_message = "";

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["alterar_perfil"])) {
    // Recuperar os dados do formulário
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $nif = $_POST["nif"];
    $data_inicio = $_POST["data_inicio"];
    $tipo_embalagem = $_POST["tipo_embalagem"];
    $tipo_lentes = $_POST["tipo_lentes"];
    $email_anterior = $_POST["email_anterior"];
    $nif_anterior = $_POST["nif_anterior"];

    // Verificar se o novo e-mail já está em uso
    $sql_verificar_email = "SELECT * FROM usuarios WHERE email=?";
    $stmt_verificar_email = $conn->prepare($sql_verificar_email);
    $stmt_verificar_email->bind_param("s", $email);
    $stmt_verificar_email->execute();
    $result_verificar_email = $stmt_verificar_email->get_result();

    // Se o novo e-mail já estiver em uso, definir mensagem de erro
    if ($result_verificar_email->num_rows > 0 && $email != $email_anterior) {
        $error_message = "O e-mail já está em uso por outro usuário. Por favor, escolha outro.";
    } else {
        // Preparar a consulta SQL para atualizar os dados do perfil
        $sql_atualizar_perfil = "UPDATE usuarios SET nome=?, email=?, data_inicio=?, embalagem=?, lente=?, nif=? WHERE email=?";
        $stmt_atualizar_perfil = $conn->prepare($sql_atualizar_perfil);
        $stmt_atualizar_perfil->bind_param("sssssss", $nome, $email, $data_inicio, $tipo_embalagem, $tipo_lentes, $nif, $email_anterior);

        // Executar a consulta para atualizar o perfil
        if ($stmt_atualizar_perfil->execute()) {
            // Verificar se a atualização foi bem-sucedida
            if ($stmt_atualizar_perfil->affected_rows > 0) {
                // Definir mensagem de sucesso
                $success_message = "Perfil atualizado com sucesso.";
                // Redirecionar para a página de sucesso
                header("Location: sucesso.html");
                exit();
            } else {
                $error_message = "Nenhuma alteração foi feita.";
            }
        } else {
            $error_message = "Erro ao executar a consulta: " . $stmt_atualizar_perfil->error;
        }

        // Fechar a declaração
        $stmt_atualizar_perfil->close();
    }

    // Fechar a declaração
    $stmt_verificar_email->close();
}

// Verificar se o parâmetro de e-mail foi fornecido na URL
if (isset($_GET['email'])) {
    // Consultar o banco de dados para obter as informações do perfil com o e-mail fornecido
    $email = $_GET['email'];
    $sql_obter_perfil = "SELECT * FROM usuarios WHERE email=?";
    $stmt_obter_perfil = $conn->prepare($sql_obter_perfil);
    $stmt_obter_perfil->bind_param("s", $email);
    $stmt_obter_perfil->execute();
    $result_obter_perfil = $stmt_obter_perfil->get_result();

    // Verificar se o perfil foi encontrado
    if ($result_obter_perfil->num_rows > 0) {
        // Obter os dados do perfil
        $perfil = $result_obter_perfil->fetch_assoc();
        $nome_perfil = $perfil['nome'];
        $nif_perfil = $perfil['nif'];
        $data_inicio_perfil = $perfil['data_inicio'];
        $embalagem_perfil = $perfil['embalagem'];
        $lente_perfil = $perfil['lente'];
        $email_anterior = $perfil['email'];
        $nif_anterior = $perfil['nif'];
    } else {
        // Se o perfil não for encontrado, redirecionar para a página de erro
        header("Location: erro.html");
        exit();
    }

    // Fechar a declaração
    $stmt_obter_perfil->close();
} else {
    // Se o parâmetro de e-mail não foi fornecido, redirecionar para a página de erro
    header("Location: erro.html");
    exit();
}

// Fechar a conexão com o banco de dados
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="alterar_total.css">
    <title>Alterar Perfil</title>
</head>
<body>
<div class="container">
    <h2>Alterar Perfil</h2>

    <!-- Exibir mensagem de erro -->
    <?php if (!empty($error_message)): ?>
        <div style="color: red; margin-bottom: 10px;"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <!-- Exibir mensagem de sucesso -->
    <?php if (!empty($success_message)): ?>
        <div style="color: green; margin-bottom: 10px;"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="textfield">
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Nome" value="<?php echo isset($nome_perfil) ? $nome_perfil : ''; ?>" required>
        </div>
        <div class="textfield">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" placeholder="Email" value="<?php echo isset($email) ? $email : ''; ?>" required>
        </div>
        <div class="textfield">
            <label for="nif">NIF</label>
            <input type="text" name="nif" id="nif" placeholder="NIF" value="<?php echo isset($nif_perfil) ? $nif_perfil : ''; ?>" required>
        </div>
        <div class="textfield">
            <label for="data_inicio">Data de Início</label>
            <input type="date" name="data_inicio" id="data_inicio" value="<?php echo isset($data_inicio_perfil) ? $data_inicio_perfil : ''; ?>" required>
        </div>
        <div class="textfield">
            <label for="tipo_embalagem">Tipo de Embalagem</label>
            <div class="select-container">
                <select id="tipo_embalagem" name="tipo_embalagem" required>
                    <option value="1" <?php echo (isset($embalagem_perfil) && $embalagem_perfil == "1") ? "selected" : ""; ?>>1 unidade</option>
                    <option value="3" <?php echo (isset($embalagem_perfil) && $embalagem_perfil == "3") ? "selected" : ""; ?>>3 unidades</option>
                    <option value="6" <?php echo (isset($embalagem_perfil) && $embalagem_perfil == "6") ? "selected" : ""; ?>>6 unidades</option>
                    <option value="30" <?php echo (isset($embalagem_perfil) && $embalagem_perfil == "30") ? "selected" : ""; ?>>30 unidades</option>
                    <option value="90" <?php echo (isset($embalagem_perfil) && $embalagem_perfil == "90") ? "selected" : ""; ?>>90 unidades</option>
                </select>
                <span class="select-arrow"></span>
            </div>
        </div>
        <div class="textfield">
            <label for="tipo_lentes">Tipo de Lentes</label>
            <div class="select-container">
                <select id="tipo_lentes" name="tipo_lentes" required>
                    <option value="Diária" <?php echo (isset($lente_perfil) && $lente_perfil == "Diária") ? "selected" : ""; ?>>Diária</option>
                    <option value="Quinzenal" <?php echo (isset($lente_perfil) && $lente_perfil == "Quinzenal") ? "selected" : ""; ?>>Quinzenal</option>
                    <option value="Mensal" <?php echo (isset($lente_perfil) && $lente_perfil == "Mensal") ? "selected" : ""; ?>>Mensal</option>
                    <option value="Trimestral" <?php echo (isset($lente_perfil) && $lente_perfil == "Trimestral") ? "selected" : ""; ?>>Trimestral</option>
                    <option value="Anual" <?php echo (isset($lente_perfil) && $lente_perfil == "Anual") ? "selected" : ""; ?>>Anual</option>
                </select>
                <span class="select-arrow"></span>
            </div>
        </div>
        <input type="hidden" name="email_anterior" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>">
        <input type="hidden" name="nif_anterior" value="<?php echo isset($nif_anterior) ? $nif_anterior : ''; ?>">
        <input type="submit" name="alterar_perfil" value="Alterar">
        <a href="../Index.php"><button type="button">Voltar</button></a>
    </form>
</div>
</body>
</html>
