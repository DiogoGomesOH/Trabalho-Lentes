<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "teste");

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Inicializar a variável de erro
$error_message = "";

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["alterar"])) {
    // Obter os valores do formulário
    $email = $_POST["email"];
    $nif = $_POST["nif"];

    // Consultar se o usuário com o email e NIF fornecidos existe
    $sql = "SELECT * FROM usuarios WHERE email = '$email' AND nif = '$nif'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Perfil encontrado, redirecionar para a página de alteração com os parâmetros de email e NIF
        header("Location: mudarcompleto.php?email=$email&nif=$nif");
        exit();
    } else {
        // Perfil não encontrado, definir a mensagem de erro
        $error_message = "Nenhum perfil encontrado com essas credenciais.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="alterarstyle.css">
    <title>Alterar Perfil</title>
</head>
<body>
    <div class="container">
        <h2>Verificar se o perfil existe</h2>

        <form method="POST" action="" onsubmit="return validateForm()">
            <div class="textfield">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" placeholder="Email" required>
            </div>
            <h2></h2>
            <div class="textfield">
                <label for="nif">NIF</label>
                <input type="text" name="nif" id="nif" placeholder="NIF" required>
            </div>
            <h2></h2>

            <!-- Exibir mensagem de erro -->
            <?php if (!empty($error_message)): ?>
                <div style="color: red; margin-bottom: 10px;"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <input type="submit" name="alterar" value="Alterar">
        </form>
    </div>

    <script>
        // Função para validar o formulário antes de enviar
        function validateForm() {
            var email = document.getElementById("email").value;
            var nif = document.getElementById("nif").value;

            // Verificar se os campos estão vazios
            if (email === "" || nif === "") {
                alert("Por favor, preencha todos os campos.");
                return false; // Impedir o envio do formulário
            }

            // Se todos os campos estiverem preenchidos, permitir o envio do formulário
            return true;
        }
    </script>
</body>
</html>
